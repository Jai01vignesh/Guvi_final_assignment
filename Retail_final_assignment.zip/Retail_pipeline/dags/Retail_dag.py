from datetime import datetime, timedelta
import os
import logging
import psycopg2
from airflow import DAG
from airflow.providers.amazon.aws.operators.s3 import S3CreateBucketOperator
from airflow.providers.amazon.aws.transfers.local_to_s3 import LocalFilesystemToS3Operator
from airflow.providers.amazon.aws.operators.emr import EmrCreateJobFlowOperator
from airflow.providers.amazon.aws.operators.emr import EmrAddStepsOperator
from airflow.providers.amazon.aws.sensors.emr import EmrStepSensor
from airflow.providers.amazon.aws.operators.emr import EmrTerminateJobFlowOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.operators.python import PythonOperator
from airflow.hooks.base import BaseHook
from airflow.hooks.S3_hook import S3Hook
from airflow.providers.amazon.aws.hooks.emr import EmrHook
from airflow.operators.bash import BashOperator


BUCKET_NAME = "retail-pipeline-guvi"
local_features = "/data/Features_data_set"
local_stores = "/data/Store_Dataset"
local_sales = "/data/Sales_Dataset"
local_scripts = "/scripts"
s3_features_data = "retail_data/features_data/"
s3_stores_data = "retail_data/stores_data/"
s3_sales_data = "retail_data/sales_data/"
s3_script = "retail_scripts/scripts/"
glue_bucket = "guvi-retail-sales"

# Define DAG arguments
default_args = {
    'owner': 'ignddev',
    'depends_on_past': False,
    'start_date': datetime(2024, 7, 6),
    "email": ["ignoreddev@gmail.com"],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Define AWS S3 credentials
aws_conn_id = 'aws_default'
aws_hook = BaseHook.get_connection(aws_conn_id)
s3_hook = S3Hook(aws_conn_id=aws_conn_id)
#emr_hook = EmrHook(aws_conn_id='aws_default')
# DAG definition
dag = DAG(
    'retail_pipeline',
    default_args=default_args,
    description='Process feature files from on-premises to AWS HDFS and then to Hive',
    schedule_interval=None,  # Set the schedule interval as needed
)

#check if s3 bucket exists
def check_s3_bucket_existence(bucket_name):
    buckets = s3_hook.get_all_buckets()
    for bucket in buckets:
        if bucket.name == bucket_name:
            return True
    return False

# Create logs bucket
#def create_s3_bucket(bucket_name):
#    #try:
#        #check_s3_bucket_existence(bucket_name)
#    #    print(f"Bucket '{bucket_name}' exists and is accessible.")
#    #except:
#        s3_hook.create_bucket(bucket_name=bucket_name, region_name='ap-south-1')



# Task to copy files from local to S3
def copy_files_to_s3(filepath,  bucket_name, key):
    """
    Function to to load files to S3 bucket. 
    
    Input: 
        filepath: source file to be migrated
        key: S3 folder/key
        bucket_name: S3 bucket with a default value already in place

    Output:
        Return nothing. This function ensure the files in the filepath are migrated to S3.
    """
    for root, dirs, files in os.walk(f"{os.getcwd()}/{filepath}"):
        for filename in files:
            file_path = f"{root}/{filename}"
            s3_hook.load_file(
                filename=file_path, key=f"{key}{filename}", bucket_name=bucket_name, replace=True)
            
def push_to_postgres(create_table_query):
    conn = psycopg2.connect(
            host='sales-data.cxewiemc0368.ap-south-1.rds.amazonaws.com',
            dbname='retail_data',
            user='postgres',
            password='brock_lesnar_22',
            port=5432
        )
    cur = conn.cursor()
    cur.execute(create_table_query)
    try:
        conn.commit()
    finally:
        cur.close()
        conn.close()



#Bucket Creation
#create_pipeline_bucket = PythonOperator(
#    task_id='create_pipeline_bucket',
#    python_callable=create_s3_bucket,
#    op_kwargs={'bucket_name': BUCKET_NAME},
#    dag=dag,
#)

#Loading local files to S3
   
Transfer_features_data_local_s3 = PythonOperator( #feature data files 
    task_id='Transfer_features_data_local_s3',
    python_callable=copy_files_to_s3,
     op_kwargs={"filepath": local_features, "bucket_name" :BUCKET_NAME, "key": s3_features_data},
    dag=dag,
)


Transfer_stores_data_localstores_s3 = PythonOperator( #stores data files
    task_id='Transfer_stores_data_local_s3',
    python_callable=copy_files_to_s3,
     op_kwargs={"filepath": local_stores, "bucket_name" :BUCKET_NAME, "key": s3_stores_data},
    dag=dag,
)  


Transfer_sales_data_localsales_s3 = PythonOperator( #sales data files
    task_id='Transfer_sales_data_local_s3',
    python_callable=copy_files_to_s3,
     op_kwargs={"filepath": local_sales, "bucket_name" :BUCKET_NAME, "key": s3_sales_data},
    dag=dag,
)  


Transfer_scripts_local_s3 = PythonOperator( #scripts
    task_id='Transfer_scripts_local_s3',
    python_callable=copy_files_to_s3,
     op_kwargs={"filepath": local_scripts, "bucket_name" :BUCKET_NAME, "key": s3_script},
    dag=dag,
)



 ##[START howto_operator_glue]
submit_glue_job = GlueJobOperator(
    task_id="submit_glue_job",
    job_name="sales_glue",
    script_location=f"s3://retail-pipeline-guvi/retail_scripts/scripts/glue_script.py",
    ##s3_bucket=glue_bucket,
    iam_role_name='Gjk',
    region_name='ap-south-1',
    create_job_kwargs={"GlueVersion": "4.0", "NumberOfWorkers": 2, "WorkerType": "G.1X"},
)

sales_create_query= """CREATE TABLE IF NOT EXISTS 
    sales(Store NUMERIC,Dept NUMERIC,Date varchar(15),Weekly_Sales varchar(25),IsHoliday varchar(15));
    """

stores_create_query= """CREATE TABLE IF NOT EXISTS 
    stores(Store NUMERIC,type varchar(2),size varchar(15));
    """

## Push to RDS
push_to_postgres_task_sales = PythonOperator(
        task_id='push_to_postgres_sales',
        python_callable=push_to_postgres,
        op_kwargs={"create_table_query":sales_create_query},
        dag =dag,
        provide_context=True
    )

push_to_postgres_task_stores = PythonOperator(
        task_id='push_to_postgres_stores',
        python_callable=push_to_postgres,
        op_kwargs={"create_table_query":stores_create_query},
        dag =dag,
        provide_context=True
    )


JOB_FLOW_OVERRIDES = {
    "Name": "Stage-2",
    "ReleaseLabel": "emr-7.2.0",
    "Applications": [{"Name": "Hadoop"},{"Name": "Hue"},{"Name": "Tez"},{"Name": "Pig"},{"Name": "HBase"}, {"Name": "Spark"}, {"Name": "Hive"}, {"Name": "Sqoop"}],
    "Configurations": [
        {
            "Classification": "spark-env",
            "Configurations": [
                {
                    "Classification": "export",
                    "Properties": {"PYSPARK_PYTHON": "/usr/bin/python3"},
                },
            ],

        },
    ],
    "Instances": {
        "InstanceGroups": [
            {
                "Name": "Master node",
                "Market": "ON_DEMAND",
                "InstanceRole": "MASTER",
                "InstanceType": "m5a.xlarge",
                "InstanceCount": 1,
            },
            {
                "Name": "Core Node",
                "Market": "SPOT",
                "InstanceRole": "CORE",
                "InstanceType": "m5a.xlarge",
                "InstanceCount": 1,
            },
            {
                "Name": "Task Node",
                "Market": "SPOT",
                "InstanceRole": "TASK",
                "InstanceType": "m5.xlarge",
                "InstanceCount": 1,
            },
        ],
        "KeepJobFlowAliveWhenNoSteps": True,
        "TerminationProtected": False,
    },
    "JobFlowRole": "EMR_EC2_DefaultRole",
    "ServiceRole": "EMR_DefaultRole",
    "LogUri": "s3://retail-pipeline-guvi/retail_files_pip/logs/",
    "VisibleToAllUsers": True
}
create_emr_cluster = EmrCreateJobFlowOperator(
    task_id="create_emr_cluster",
    job_flow_overrides=JOB_FLOW_OVERRIDES,
    aws_conn_id="aws_default",
    region_name='ap-south-1',
    dag=dag
)


# Task to create new HDFS directory in AWS (S3)
SPARK_STEPS1 = [
    {
        "Name": "Data files from S3 to HDFS",
        "ActionOnFailure": "CANCEL_AND_WAIT",
        "HadoopJarStep": {
            "Jar": "command-runner.jar",
            "Args": [
                "s3-dist-cp",
                "--src=s3://{{ params.BUCKET_NAME }}/{{ params.s3_features_data }}",
                "--dest=hdfs:///usr/hadoop/features/",
            ],
        },
    },]
SPARK_STEPS2 = [
    {
        "Name": "Create Hive Table",
        "ActionOnFailure": "CANCEL_AND_WAIT",
        "HadoopJarStep": {
            "Jar": "command-runner.jar",
            "Args": [
                "spark-submit",
                "--deploy-mode",
                "cluster",
               "s3://{{ params.BUCKET_NAME }}//{{ params.s3_script }}/hdfs_hive_features_data.py",
           ],
       },
   },]
SPARK_STEPS3 = [
    {
        "Name": "export RDS to S3",
        "ActionOnFailure": "CANCEL_AND_WAIT",
        "HadoopJarStep": {
            "Jar": "s3://ap-south-1.elasticmapreduce/libs/script-runner/script-runner.jar",
            "Args": [
                "s3://retail-pipeline-guvi/retail_scripts/scripts/sqoop.sh",
           ],
       },
   },
  
]
SPARK_STEPS4 = [
    {
        "Name": "create_retail_processed_data",
        "ActionOnFailure": "CANCEL_AND_WAIT",
        "HadoopJarStep": {
            "Jar": "command-runner.jar",
            "Args": [
                "spark-submit",
                "--deploy-mode",
                "cluster",
               "s3://{{ params.BUCKET_NAME }}//{{ params.s3_script }}/spark_process.py",
           ],
       },
   },
  
]



# Create the EMR hook and operator

step_adder1 = EmrAddStepsOperator(
    task_id='add_spark_step1',
    job_flow_id="{{ task_instance.xcom_pull(task_ids='create_emr_cluster', key='return_value') }}",
    aws_conn_id='aws_default',
    params={
       "BUCKET_NAME": BUCKET_NAME,
       "s3_features_data": s3_features_data,
       "s3_script": s3_script
   },
    steps=SPARK_STEPS1,
    dag=dag  # Replace with your DAG object
)

step_adder2 = EmrAddStepsOperator(
    task_id='add_spark_step2',
    job_flow_id="{{ task_instance.xcom_pull(task_ids='create_emr_cluster', key='return_value') }}",
    aws_conn_id='aws_default',
    params={
       "BUCKET_NAME": BUCKET_NAME,
       "s3_features_data": s3_features_data,
       "s3_script": s3_script
   },
    steps=SPARK_STEPS2,
    dag=dag  # Replace with your DAG object
)

step_adder3 = EmrAddStepsOperator(
    task_id='add_spark_step3',
    job_flow_id="{{ task_instance.xcom_pull(task_ids='create_emr_cluster', key='return_value') }}",
    aws_conn_id='aws_default',
    params={
       "BUCKET_NAME": BUCKET_NAME,
       "s3_features_data": s3_features_data,
       "s3_script": s3_script
   },
    steps=SPARK_STEPS3,
    dag=dag  # Replace with your DAG object
)

step_adder4 = EmrAddStepsOperator(
    task_id='add_spark_step4',
    job_flow_id="{{ task_instance.xcom_pull(task_ids='create_emr_cluster', key='return_value') }}",
    aws_conn_id='aws_default',
    params={
       "BUCKET_NAME": BUCKET_NAME,
       "s3_features_data": s3_features_data,
       "s3_script": s3_script
   },
    steps=SPARK_STEPS4,
    dag=dag  # Replace with your DAG object
)

# wait for the steps to complete
step_sensor_task = EmrStepSensor(
    task_id='watch_spark_step',
    job_flow_id="{{ task_instance.xcom_pull(task_ids='create_emr_cluster', key='return_value') }}",
    step_id="{{ task_instance.xcom_pull(task_ids='add_spark_step4', key='return_value')[0] }}",
    aws_conn_id='aws_default',  # Ensure AWS connection is configured in Airflow
    dag=dag,
)


# Task to terminate EMR cluster
terminate_emr_task = EmrTerminateJobFlowOperator(
    task_id='terminate_emr_cluster',
    job_flow_id="{{ task_instance.xcom_pull(task_ids='create_emr_cluster', key='return_value') }}",
    aws_conn_id='aws_default',  # AWS connection ID configured in Airflow
    dag=dag,
)

delay_bash_task: BashOperator = BashOperator(task_id="delay_bash_task",
                                             dag=dag,
                                             bash_command="sleep 5m")

# Define task dependencies
Transfer_scripts_local_s3 
#Stage-3
Transfer_stores_data_localstores_s3 >> push_to_postgres_task_stores
#Stage-2
Transfer_features_data_local_s3 >> delay_bash_task >> create_emr_cluster >> step_adder1 >> step_adder2 >> step_adder3 >> step_adder4 >> step_sensor_task >> terminate_emr_task
#Stage-1
Transfer_sales_data_localsales_s3 >> push_to_postgres_task_sales>> submit_glue_job





