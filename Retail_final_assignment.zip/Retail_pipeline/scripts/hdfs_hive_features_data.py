from pyspark.sql import SparkSession
##.master("spark://ec2-3-110-214-146.ap-south-1.compute.amazonaws.com")
# Create Spark session
spark = SparkSession.builder.appName("ProcessFeatureData").enableHiveSupport().getOrCreate()

df = spark.read.csv("hdfs:///usr/hadoop/features/*.csv" , header=True, inferSchema=True)
df.write.saveAsTable("default.features_data",format ="parquet",mode ="overwrite",path ="s3://retail-pipeline-guvi/hive_table/features/")

# Stop Spark session
spark.stop()
