import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)


AmazonS3_node1725070279118 = glueContext.create_dynamic_frame.from_options(format_options={"quoteChar": "\"", "withHeader": True, "separator": ",", "multiline": True, "optimizePerformance": False}, connection_type="s3", format="csv", connection_options={"paths": ["s3://retail-pipeline-guvi/retail_data/sales_data/"], "recurse": True}, transformation_ctx="AmazonS3_node1725070279118")

#Repartition
repartion12 = AmazonS3_node1725070279118.repartition(1)



AmazonS3_node1725070298950 = glueContext.write_dynamic_frame.from_options(frame=repartion12, connection_type="s3", format="csv", connection_options={"path": "s3://guvi-retail-sales/", "partitionKeys": []}, transformation_ctx="AmazonS3_node1725070298950")


# rename created file
import boto3
client = boto3.client('s3')
bucket_name = "guvi-retail-sales"
#getting all the content/file inside the bucket. 
response = client.list_objects_v2(Bucket=bucket_name)
names = response["Contents"]

#Find out the file which have part-000* in it's Key
particulars = [name['Key'] for name in names if 'part-r-00000' in name['Key']]

#Find out the prefix of part-000* because we want to retain the partitions schema 
location = [particular.split('part-000')[0] for particular in particulars]

#Constraint - copy_object has limit of 5GB
for key,particular in enumerate(particulars):
    client.copy_object(Bucket=bucket_name, CopySource=bucket_name + "/" + particular, Key="sales_data.csv")
    client.delete_object(Bucket=bucket_name, Key=particular)

job.commit()