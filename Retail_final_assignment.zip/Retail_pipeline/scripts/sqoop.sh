!/bin/bash
cd $SQOOP_HOME/
sudo mkdir /var/lib/accumulo
ACCUMULO_HOME='/var/lib/accumulo'
export ACCUMULO_HOME
echo $ACCUMULO_HOME

sudo wget -O postgresql-jdbc.jar https://jdbc.postgresql.org/download/postgresql-42.3.1.jar
sudo mv postgresql-jdbc.jar /usr/lib/sqoop/lib/
cd /usr/lib/sqoop/lib/
ls
sqoop import --connect jdbc:postgresql://sales-data.cxewiemc0368.ap-south-1.rds.amazonaws.com/retail_data --username postgres --password brock_lesnar_22 --table stores --target-dir s3://retail-pipeline-guvi/sqoop_s3/stores/ --as-parquetfile --m 1 --fields-terminated-by ','
sqoop import --connect jdbc:postgresql://sales-data.cxewiemc0368.ap-south-1.rds.amazonaws.com/retail_data --username postgres --password brock_lesnar_22 --table sales --target-dir s3://retail-pipeline-guvi/sqoop_s3/sales/ --as-parquetfile --m 1 --fields-terminated-by ','
