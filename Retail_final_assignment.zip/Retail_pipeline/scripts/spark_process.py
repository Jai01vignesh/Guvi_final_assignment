from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json
from pyspark.sql.functions import date_format
from datetime import datetime
import pyspark.sql.types as T
import pyspark.sql.functions as F
# Initialize Spark Session
spark = SparkSession.builder.appName("retail_data_processing").enableHiveSupport().getOrCreate()
    
stores = spark.read.parquet("s3://retail-pipeline-guvi/sqoop_s3/stores/*.parquet")
sales = spark.read.parquet('s3://retail-pipeline-guvi/sqoop_s3/sales/*.parquet')
features = spark.read.parquet('s3://retail-pipeline-guvi/hive_table/features/*.parquet')


Retail_frame=features.join(stores,["store"]) \
     .join(sales,[features["date"] == sales["date"],features["store"] == sales["store"]]).drop(sales.store,sales.date,sales.isholiday,stores.store).fillna(0)
def user_defined_timestamp(date_col):
    _date = datetime.strptime(date_col, '%d/%m/%Y')
    return _date.strftime('%Y-%m-%d')

user_defined_timestamp_udf = F.udf(user_defined_timestamp, T.StringType())
Retail_frame = Retail_frame.withColumn('Date_formatted', user_defined_timestamp_udf('Date')).drop("Date")

Retail_frame.toPandas().to_csv("s3://retail-pipeline-guvi/retail_processed_data.csv", header=True)
spark.stop()
